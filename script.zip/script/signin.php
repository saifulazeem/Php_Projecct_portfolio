<!DOCTYPE html>
<html>
<head>
	<title>Sigin</title>
</head>
<?php

include("connection.php");
?>
<style type="text/css">
.login
{
	width: 20%;
	height: 300px;
	background: black;
	color: White;
	padding: 20px;

}
.label
{
	float: left;
	font-size: 16px;
	color:White;
	font-family:Arial;
}
	
</style>
<body>
	<br>
	<br>
	<br>
	<br>
	<center>
		<div class="login">
		<h1>Login</h1>
		<form action="sigin.php" method="post">
			<label class="label" for="Input Email">Email</label><br>
			<input type="Email" name="u_mail" id="i_Email" placeholder="Enter your Email" autofocus="required">
			<br>
			<br>
			<label class="label" for="Input Password">Password</label>
			<br>
			<input type="password" name="u_password" placeholder="Enter your password" required">
			<br>
			<br>
			<button type="submit" name="u_login" id="log">Login</button>
			
		</form>
		

	</div></center>

</body>
</html>


<?php
if (isset($POST["u_login"]))
{
	$user=mysqli_real_escape_string($con,$POST["u_mail"]);
	$pass=mysqli_real_escape_string($con,$POST["u_password"]);

	$query=$con->prepare("SELECT * FROM user WHERE email=? AND password=?");
	$query->bind_param("ss", $user, $pass);
	$query->execute();
	$result=$query->get_result();

	if($result->num_rows===0)
	{
		exit("No user Exist");
	}

	while($row=$result->fetch_assoc())
	{
		$id=$row["id"];
		$user=$row["email"];
		$pass=$row["password"];

	}

	$query->close();


	session_start();

	header("location: index.php");
}

?>